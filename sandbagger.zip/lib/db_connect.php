<?php
// lib/db_connect.php

// 1) Database credentials — adjust these to match your setup
$servername = "localhost";
$username = "kbr37";
$password = "Knikado3720";
$dbname = "sandbagger";

// 2) Enable exceptions for easier error handling
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // 3) Establish the connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // 4) Set the charset to UTF-8
    $conn->set_charset('utf8mb4');
} 
catch (mysqli_sql_exception $e) {
    // 5) Log the detailed error and return a generic JSON response
    error_log('DB Connection Error: ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}
