<?php
// db_connect.php

$servername = "localhost";  // e.g., "localhost"
$username   = "kbr37";     // e.g., "root"
$password   = "Knikado3720";     // e.g., ""
$dbname   = "sandbagger";     // e.g., "my_database"

// Connect
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  http_response_code(500);
  echo json_encode(['error' => 'Database connection failed']);
  exit;
}
